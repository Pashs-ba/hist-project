const { test, expect } = require('@playwright/test');

test.use({ locale: 'en-US' });

const appleProducts = ['Apple Juice (1000ml)', 'Apple Pomace', 'Pineapple Juice (1000ml)'];
const missingProduct = 'MandarinSorbetNoMatch742';

function products(page) {
  return page.getByRole('article').getByRole('button', {
    name: 'Click for more information about the product',
  });
}

async function search(page, query) {
  const field = page.getByRole('textbox');
  await field.fill(query);
  await field.press('Enter');
  if (query) {
    await expect(page.locator('#searchValue')).toHaveText(query.trim());
  }
}

test.beforeEach(async ({ page }) => {
  await page.goto('/');
  await page.getByRole('button', { name: 'Close Welcome Banner' }).click();
  await page.getByRole('button', { name: 'dismiss cookie message' }).click();
  await expect(products(page).first()).toBeVisible();
  await page.getByRole('button', { name: 'Open search' }).click();
});

test.describe('Обработка регистра, пробелов и знаков препинания', () => {
  test('Нижний, верхний и смешанный регистр дают одни и те же товары', async ({ page }) => {
    for (const query of ['apple', 'APPLE', 'ApPlE']) {
      await search(page, query);
      await expect(products(page)).toHaveText(appleProducts);
    }
  });

  test('Начальные и конечные пробелы не меняют результат поиска по названию', async ({ page }) => {
    await search(page, '  Apple Pomace  ');
    await expect(products(page)).toHaveText(['Apple Pomace']);
  });

  test('Название с кавычками находится при вводе вместе с кавычками', async ({ page }) => {
    const name = 'Juice Shop "Permafrost" 2020 Edition';
    await search(page, name);
    await expect(products(page)).toHaveText([name]);
  });
});

test.describe('Отображение найденных товаров и переход к их карточкам', () => {
  test('В выдаче Apple видны названия всех трёх найденных товаров', async ({ page }) => {
    await search(page, 'Apple');
    await expect(products(page)).toHaveText(appleProducts);
    for (const name of appleProducts) {
      await expect(page.getByRole('article').getByText(name, { exact: true })).toBeVisible();
    }
  });

  test('Открывается выбранная карточка, после её закрытия сохраняется выдача', async ({ page }) => {
    await search(page, 'Apple');
    await products(page).filter({ hasText: 'Apple Pomace' }).click();

    const dialog = page.getByRole('dialog').filter({
      has: page.getByRole('heading', { name: 'Apple Pomace', exact: true }),
    });
    await expect(dialog).toBeVisible();
    await expect(dialog.getByText('0.89¤', { exact: true })).toBeVisible();
    await dialog.getByRole('button', { name: 'Close Dialog' }).click();
    await expect(dialog).toBeHidden();
    await expect(products(page)).toHaveText(appleProducts);
  });
});

test.describe('Навигация по страницам результатов поиска', () => {
  test('Вперёд и назад меняют товары и восстанавливают первую страницу', async ({ page }) => {
    await search(page, 'juice');
    const range = page.getByRole('status');
    const previous = page.getByRole('button', { name: 'Previous page' });
    await expect(previous).toBeDisabled();
    await expect(range).toHaveText(/1\s*–\s*15 of 36/);
    await expect(products(page)).toHaveCount(15);
    const firstPage = await products(page).allTextContents();

    await page.getByRole('button', { name: 'Next page' }).click();
    await expect(range).toHaveText(/16\s*–\s*30 of 36/);
    await expect(products(page)).toHaveCount(15);
    const secondPage = await products(page).allTextContents();
    expect(secondPage.filter(name => firstPage.includes(name))).toEqual([]);

    await previous.click();
    await expect(range).toHaveText(/1\s*–\s*15 of 36/);
    await expect(products(page)).toHaveText(firstPage);
    await expect(previous).toBeDisabled();
  });

  test('На последней странице виден остаток выдачи, переход вперёд недоступен', async ({ page }) => {
    await search(page, 'juice');
    const next = page.getByRole('button', { name: 'Next page' });
    await next.click();
    await next.click();
    await expect(page.getByRole('status')).toHaveText(/31\s*–\s*36 of 36/);
    await expect(products(page)).toHaveCount(6);
    await expect(products(page).last()).toHaveText('Strawberry Juice (500ml)');
    await expect(next).toBeDisabled();
    await expect(page.getByRole('button', { name: 'Previous page' })).toBeEnabled();
  });
});

test.describe('Отображение результата при отсутствии совпадений', () => {
  test('Вместо товаров появляется сообщение об отсутствии результатов', async ({ page }) => {
    await search(page, missingProduct);
    await expect(page.getByText('No results found', { exact: true })).toBeVisible();
    await expect(products(page)).toHaveCount(0);
    await expect(page.getByRole('status')).toHaveText('0 of 0');
  });
});

test.describe('Изменение запроса и обновление результатов', () => {
  test('Новый запрос со второй страницы заменяет старую выдачу и сбрасывает страницу', async ({ page }) => {
    await search(page, 'juice');
    await page.getByRole('button', { name: 'Next page' }).click();
    await expect(page.getByRole('status')).toHaveText(/16\s*–\s*30 of 36/);

    await search(page, 'Apple');
    await expect(products(page)).toHaveText(appleProducts);
    await expect(page.getByRole('status')).toHaveText(/1\s*–\s*3 of 3/);
    await expect(page.getByRole('button', { name: 'Previous page' })).toBeDisabled();
  });

  test('После запроса без совпадений новый запрос снова показывает товары', async ({ page }) => {
    await search(page, missingProduct);
    const emptyMessage = page.getByText('No results found', { exact: true });
    await expect(emptyMessage).toBeVisible();

    await search(page, 'Banana');
    await expect(products(page)).toHaveText(['Banana Juice (1000ml)']);
    await expect(emptyMessage).toBeHidden();
  });
});

test.describe('Очистка запроса и возврат к полному каталогу', () => {
  test('Учебный пример: очистка со второй страницы возвращает на первую страницу каталога', async ({ page }) => {
    const range = page.getByRole('status');
    const firstCatalogPage = (await range.innerText()).trim();

    await test.step('Открыть вторую страницу результатов поиска juice', async () => {
      await search(page, 'juice');
      await page.getByRole('button', { name: 'Next page' }).click();
      await expect(range).toHaveText('16 – 30 of 36');
    });

    await test.step('Очистить запрос и проверить номер страницы полного каталога', async () => {
      await search(page, '');
      await expect(page.getByRole('main').getByText('All Products', { exact: true })).toBeVisible();
      await expect(range, 'После очистки каталог должен открыться на первой странице').toHaveText(firstCatalogPage);
    });
  });

  for (const scenario of [
    { title: 'Очистка после успешного поиска', query: 'Apple', resultCount: 3 },
    { title: 'Очистка после поиска без совпадений', query: missingProduct, resultCount: 0 },
  ]) {
    test(scenario.title, async ({ page }) => {
      const range = page.getByRole('status');
      const catalogRange = (await range.innerText()).trim();
      const catalogPage = await products(page).allTextContents();
      await search(page, scenario.query);
      await expect(products(page)).toHaveCount(scenario.resultCount);

      await search(page, '');
      await expect(page.getByRole('main').getByText('All Products', { exact: true })).toBeVisible();
      await expect(page.getByRole('textbox')).toHaveValue('');
      await expect(range).toHaveText(catalogRange);
      await expect(products(page)).toHaveText(catalogPage);
    });
  }
});
